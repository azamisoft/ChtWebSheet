(function(){
  var info = {
  "appName": "Cht WebSheet",
  "company": "株式会社CHT",
  "version": "0.1.8",
  "runtimeVersion": "0.1.8",
  "runtimeUpdatedAt": "2026-06-14T10:50:51.353Z",
  "updatedAt": "2026-06-14T10:50:51.353Z",
  "runtimeChannel": "current",
  "baseUrl": "/download/runtime/0.1.8",
  "appVersion": "0.1.0",
  "versionJson": {
    "appName": "Cht WebSheet",
    "company": "株式会社CHT",
    "version": "0.1.0",
    "runtimeVersion": "0.1.8",
    "runtimeUpdatedAt": "2026-06-14T10:50:51.353Z",
    "updatedAt": "2026-06-14T10:50:51.353Z",
    "runtimeChannel": "current",
    "baseUrl": "/download/runtime/0.1.8"
  }
};
  window.__WEBSHEET_STANDALONE_RUNTIME_VERSION__ = info;
  if (typeof window.__WEBSHEET_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBSHEET_RUNTIME_VERSION_PROBE__(info);
  }
})();
