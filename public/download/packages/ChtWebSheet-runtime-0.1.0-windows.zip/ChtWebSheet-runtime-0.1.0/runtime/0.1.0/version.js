(function(){
  var info = { version: "0.1.0" };
  window.__WEBSHEET_STANDALONE_RUNTIME_VERSION__ = info;
  window.__WEBEXCEL_STANDALONE_RUNTIME_VERSION__ = info;
  if (typeof window.__WEBSHEET_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBSHEET_RUNTIME_VERSION_PROBE__(info);
  }
  if (typeof window.__WEBEXCEL_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBEXCEL_RUNTIME_VERSION_PROBE__(info);
  }
})();
