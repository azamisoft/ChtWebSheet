(function(){
  var info = { version: "0.1.7", updatedAt: "2026-06-13T16:50:06.774Z" };
  window.__WEBSHEET_STANDALONE_RUNTIME_VERSION__ = info;
  if (typeof window.__WEBSHEET_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBSHEET_RUNTIME_VERSION_PROBE__(info);
  }
})();
