Cht WebSheet common runtime 0.1.7

Install on macOS:
1. Extract this zip file.
2. Double-click install.command.
3. If macOS asks for permission or an administrator password, follow the prompt.
4. The runtime will be installed to:
   /Library/Application Support/WebSheet/runtime/current
   /Library/Application Support/WebSheet/runtime/<version>
   where <version> is the runtime version included in this package.

After installation, Cht WebSheet HTML workbooks can load the local runtime offline.
Saved HTML workbooks use the stable "runtime/current" entry first, so runtime updates do not require editing old files.
You can also open ChtWebSheet.html in this package to start a blank CWS workbook.
