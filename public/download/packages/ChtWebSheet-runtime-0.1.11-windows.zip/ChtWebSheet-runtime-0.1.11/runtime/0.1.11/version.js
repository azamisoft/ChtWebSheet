(function(){
  var info = {
  "appName": "Cht WebSheet",
  "company": "株式会社CHT",
  "version": "0.1.11",
  "runtimeVersion": "0.1.11",
  "runtimeUpdatedAt": "2026-08-24T16:39:58.167Z",
  "updatedAt": "2026-08-24T16:39:58.167Z",
  "runtimeChannel": "current",
  "baseUrl": "/download/runtime/0.1.11",
  "appVersion": "0.1.0",
  "versionJson": {
    "appName": "Cht WebSheet",
    "company": "株式会社CHT",
    "version": "0.1.0",
    "runtimeVersion": "0.1.11",
    "runtimeUpdatedAt": "2026-08-24T16:39:58.167Z",
    "updatedAt": "2026-08-24T16:39:58.167Z",
    "runtimeChannel": "current",
    "baseUrl": "/download/runtime/0.1.11"
  }
};
  window.__WEBSHEET_STANDALONE_RUNTIME_VERSION__ = info;
  if (typeof window.__WEBSHEET_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBSHEET_RUNTIME_VERSION_PROBE__(info);
  }
})();
