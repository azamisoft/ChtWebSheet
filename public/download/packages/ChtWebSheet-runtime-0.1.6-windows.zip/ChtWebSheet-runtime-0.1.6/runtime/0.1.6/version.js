(function(){
  var info = { version: "0.1.6", updatedAt: "2026-06-12T18:11:01.056Z" };
  window.__WEBSHEET_STANDALONE_RUNTIME_VERSION__ = info;
  if (typeof window.__WEBSHEET_RUNTIME_VERSION_PROBE__ === "function") {
    window.__WEBSHEET_RUNTIME_VERSION_PROBE__(info);
  }
})();
