Cht WebSheet common runtime 0.1.8

Install on Windows:
1. Extract this zip file.
2. Right-click install-runtime.ps1 and run it with PowerShell.
3. The runtime will be installed to:
   C:\ProgramData\WebSheet\runtime\current
   C:\ProgramData\WebSheet\runtime\<version>
   where <version> is the runtime version included in this package.

After installation, Cht WebSheet HTML workbooks can load the local runtime offline.
Saved HTML workbooks use the stable "runtime\current" entry first, so runtime updates do not require editing old files.
You can also open ChtWebSheet.html in this package to start a blank CWS workbook.
