#!/bin/bash
set -euo pipefail

VERSION="0.1.9"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)/runtime/$VERSION"
RUNTIME_ROOT="/Library/Application Support/WebSheet/runtime"
VERSION_TARGET_DIR="$RUNTIME_ROOT/$VERSION"
CURRENT_TARGET_DIR="$RUNTIME_ROOT/current"

if [ ! -d "$SOURCE_DIR" ]; then
  echo "Runtime source not found: $SOURCE_DIR" >&2
  exit 1
fi

echo "Cht WebSheet common runtime $VERSION"
echo "Installing to: $VERSION_TARGET_DIR"
echo "Updating stable entry: $CURRENT_TARGET_DIR"
echo "管理者パスワードを求められた場合は、macOS の確認に従って入力してください。"

sudo mkdir -p "$VERSION_TARGET_DIR"
sudo cp -R "$SOURCE_DIR"/. "$VERSION_TARGET_DIR"/
sudo rm -rf "$CURRENT_TARGET_DIR"
sudo mkdir -p "$CURRENT_TARGET_DIR"
sudo cp -R "$SOURCE_DIR"/. "$CURRENT_TARGET_DIR"/
sudo chmod -R a+rX "/Library/Application Support/WebSheet"

echo ""
echo "Installation complete."
echo "You can close this window."
