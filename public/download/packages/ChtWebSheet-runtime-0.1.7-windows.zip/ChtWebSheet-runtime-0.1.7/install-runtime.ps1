# Cht WebSheet common runtime installer
$ErrorActionPreference = "Stop"
$version = "0.1.7"
$source = Join-Path $PSScriptRoot "runtime\$version"
$runtimeRoot = Join-Path $env:ProgramData "WebSheet\runtime"
$versionTarget = Join-Path $runtimeRoot $version
$currentTarget = Join-Path $runtimeRoot "current"
New-Item -ItemType Directory -Force -Path $versionTarget | Out-Null
Copy-Item -Path (Join-Path $source "*") -Destination $versionTarget -Recurse -Force
if (Test-Path $currentTarget) { Remove-Item $currentTarget -Recurse -Force }
New-Item -ItemType Directory -Force -Path $currentTarget | Out-Null
Copy-Item -Path (Join-Path $source "*") -Destination $currentTarget -Recurse -Force
Write-Host "Cht WebSheet common runtime $version installed to $versionTarget"
Write-Host "Stable runtime entry updated: $currentTarget"
